#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

const char *art_line1 = " ____        _ _______ _    _  _____ _______ ______ ";
const char *art_line2 = " |  _ \\     | |__   __| |  | |/ ____|__   __|  ____|";
const char *art_line3 = " | |_) |    | |  | |  | |  | | |       | |  | |__   ";
const char *art_line4 = " |  _ < _   | |  | |  | |  | | |       | |  |  __|  ";
const char *art_line5 = " | |_) | |__| |  | |  | |__| | |____   | |  | |     ";
const char *art_line6 = " |____/ \\____/   |_|   \\____/ \\_____|  |_|  |_|     ";
const char *art_line7 = "                                                     ";
const char *art_line8 = "                                                     ";

const char *info_line1 = "**************************************************";
const char *info_line2 = " * Founder: Expl0rer.Ct";
const char *info_line3 = " * To be honest, Do you know the FMT?";
const char *info_line4 = " * Hint  : So EZ!You can solve it when you have shou   ";
const char *info_line5 = "**************************************************";
 
int Expl0rer;
int Ct;  
unsigned int BJTUCTF()
{
    char s[80];
    unsigned int v2;
    v2 = 0;
    memset(s, 0, sizeof(s));
    read(0, s, 0x50u);
    printf(s);
    printf("Expl0rer now is :%d!\n", Ct);
    return 0 ^ v2;
}


int main()
{
    setbuf(stdout, NULL);
    setbuf(stdin, NULL);
    setbuf(stderr, NULL);

    puts(art_line1);
    puts(art_line2);
    puts(art_line3);
    puts(art_line4);
    puts(art_line5);
    puts(art_line6);
    puts(art_line7);
    puts(art_line8);
    puts(info_line1);
    puts(info_line2);
    puts(info_line3);
    puts(info_line4);
    puts(info_line5);

    BJTUCTF();
    if (Expl0rer == 6)
    {
        puts("Expl0rer praise you for getting into the BJTU!");
        system("/bin/sh");  
    }
    return 0;
}