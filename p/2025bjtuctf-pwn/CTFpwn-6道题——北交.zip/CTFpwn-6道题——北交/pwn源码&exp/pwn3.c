#include <stdio.h>
#include <string.h>
#include <unistd.h>

const char *art_line1 = " ____        _ _______ _    _  _____ _______ ______ ";
const char *art_line2 = " |  _ \\     | |__   __| |  | |/ ____|__   __|  ____|";
const char *art_line3 = " | |_) |    | |  | |  | |  | | |       | |  | |__   ";
const char *art_line4 = " |  _ < _   | |  | |  | |  | | |       | |  |  __|  ";
const char *art_line5 = " | |_) | |__| |  | |  | |__| | |____   | |  | |     ";
const char *art_line6 = " |____/ \\____/   |_|   \\____/ \\_____|  |_|  |_|     ";
const char *art_line7 = "                                                     ";
const char *art_line8 = "                                                     ";

const char *info_line1 = "**************************************************";
const char *info_line2 = " * Founder: Expl0rer.Ct";
const char *info_line3 = " * To be honest, Do you know the didderence between 64-bit architecture and 32-bit architecture?";
const char *info_line4 = " * Hint  : It has system and '/bin/sh'.There is a backdoor function   ";
const char *info_line5 = "**************************************************";


ssize_t BJTUCTF()
{
    char buf[10]; 
    return read(0, buf, 0x32uLL); 
}

int backdoor()
{
    system("/bin/sh\n");
    return 0LL;
}

int main()
{
    setbuf(stdout, NULL);
    setbuf(stdin, NULL);
    setbuf(stderr, NULL);

    puts(art_line1);
    puts(art_line2);
    puts(art_line3);
    puts(art_line4);
    puts(art_line5);
    puts(art_line6);
    puts(art_line7);
    puts(art_line8);
    puts(info_line1);
    puts(info_line2);
    puts(info_line3);
    puts(info_line4);
    puts(info_line5);

    BJTUCTF(); 
    puts("\nExpl0rer.Ct likes to use ROPgadget!!");
    return 0;
}