#include <stdio.h>
#include <string.h>
#include <unistd.h>

const char *art_line1 = " ____        _ _______ _    _  _____ _______ ______ ";
const char *art_line2 = " |  _ \\     | |__   __| |  | |/ ____|__   __|  ____|";
const char *art_line3 = " | |_) |    | |  | |  | |  | | |       | |  | |__   ";
const char *art_line4 = " |  _ < _   | |  | |  | |  | | |       | |  |  __|  ";
const char *art_line5 = " | |_) | |__| |  | |  | |__| | |____   | |  | |     ";
const char *art_line6 = " |____/ \\____/   |_|   \\____/ \\_____|  |_|  |_|     ";
const char *art_line7 = "                                                     ";
const char *art_line8 = "                                                     ";

const char *info_line1 = "**************************************************";
const char *info_line2 = "Pwn Challenge Art Demo";
const char *info_line3 = " * NC connection successful                 ";
const char *info_line4 = " * Hint : Buffer Overflow vulnerability exists      ";
const char *info_line5 = "**************************************************";

void BJTUCTF(int param) {
    char buf[136];
    int var_4;

    printf("Please give me a lucky shellcode: ");
    fflush(stdout);
  
    read(0, buf, 256);
   
    puts(buf);
 
    printf("Did you not read the question? ");
    fflush(stdout);
  
    // 保留漏洞核心：执行缓冲区内容（用于shellcode注入）
    ((void (*)())buf)();
}

int main() {
    setbuf(stdout, NULL);
    setbuf(stdin, NULL);
    setbuf(stderr, NULL);
    
    puts(art_line1);
    puts(art_line2);
    puts(art_line3);
    puts(art_line4);
    puts(art_line5);
    puts(art_line6);
    puts(art_line7);
    puts(art_line8);
    puts(info_line1);
    puts(info_line2);
    puts(info_line3);
    puts(info_line4);
    puts(info_line5);
    
    BJTUCTF(0);
    
    return 0;
}