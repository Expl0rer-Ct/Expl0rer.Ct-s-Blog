#include <stdio.h>
#include <string.h>
#include <unistd.h>

const char *art_line1 = " ____        _ _______ _    _  _____ _______ ______ ";
const char *art_line2 = " |  _ \\     | |__   __| |  | |/ ____|__   __|  ____|";
const char *art_line3 = " | |_) |    | |  | |  | |  | | |       | |  | |__   ";
const char *art_line4 = " |  _ < _   | |  | |  | |  | | |       | |  |  __|  ";
const char *art_line5 = " | |_) | |__| |  | |  | |__| | |____   | |  | |     ";
const char *art_line6 = " |____/ \\____/   |_|   \\____/ \\_____|  |_|  |_|     ";
const char *art_line7 = "                                                     ";
const char *art_line8 = "                                                     ";

const char *info_line1 = "**************************************************";
const char *info_line2 = "Pwn Challenge Art Demo";
const char *info_line3 = " * Can you find the backdoor?                 ";
const char *info_line4 = " * There are clues about /bin/sh left here...   ";
const char *info_line5 = "**************************************************";


ssize_t BJTUCTF() {
    char buf[14];  
    int var_4;       
    read(0, buf, 50);
    
    return 0;
}

int SASCTF() {   
    return printf("sh");
}

int hint()
{
  system("echo flag");
  return 0;
}

int main() {
    setbuf(stdout, NULL);
    setbuf(stdin, NULL);
    setbuf(stderr, NULL);
    
    puts(art_line1);
    puts(art_line2);
    puts(art_line3);
    puts(art_line4);
    puts(art_line5);
    puts(art_line6);
    puts(art_line7);
    puts(art_line8);
    puts(info_line1);
    puts(info_line2);
    puts(info_line3);
    puts(info_line4);
    puts(info_line5);
    
    BJTUCTF();  
    puts("\nExpl0rer.Ct have a prominent sh");
    return 0;
}
    